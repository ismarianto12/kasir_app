<?php

//     id BIGINT NOT NULL PRIMARY KEY AUTO_INCREMENT, 
//    `no_penjualan` varchar(20) DEFAULT NULL,
//    `kasir_id` varchar(100) DEFAULT NULL,  
//    `barang_id` varchar(255) NOT NULL,
//    `member_id` int(11) DEFAULT NULL,
//    `jumlah` varchar(255) NOT NULL,
//    `date_created` datetime NOT NULL,
//     date_updated datetime NOT NULL  

class Penjualan_model extends CI_model
{

    function __construct()
    {

    }
  
}
