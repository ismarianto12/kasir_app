<footer class="main-footer">
      <div class="pull-right hidden-xs">
        <b>Version</b> 0.1
      </div>
      <strong>Copyright &copy; 2020 Gaia Biai</strong> All rights
      reserved.
    </footer>