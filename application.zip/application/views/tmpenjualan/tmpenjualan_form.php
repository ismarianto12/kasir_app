<section class="content">
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                </div>
                <div class="body">
                    <div class='row'>
                        <div class='col-sm-12'>
                            <?= $this->session->flashdata('message') ?>
                            <div class=white-box>
                                Iktishar penjualan barang
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>